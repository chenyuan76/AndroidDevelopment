// pages/departments/departments.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    iswindow: false,
    isRealAuth: false,
    hospital_id: 0,
    doctorInfo:'',
    index: 0,
    list:[],
    isfinished: false
    
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    this.setData({
      hospital_id: app.globalData.hospital_id,
      list: app.globalData.hospital
    })
    // console.log(app.globalData.hospital_id)
    // console.log(app.globalData.hospital)

  },

  ShowInfo:function(e){
    let that = this
    console.log(e.target.id)
    const db = wx.cloud.database()
    db.collection("Users").where({
      Name: e.target.id
    }).get().then(res=>{
      that.setData({
        doctorInfo:res.data[0].doctorInfo
      })
      console.log(res.data[0].doctorInfo[0].doctorName)
      console.log("医生信息：",that.data.doctorInfo)
    })
    that.setData({
      iswindow: true
    })
  },

  cancel: function(){
    let that = this
    that.setData({
      iswindow: false
    })
  },
  confirm: function(){
    let that = this
    const db = wx.cloud.database()
    db.collection("Users").where({
      _openid: app.globalData.openid
    }).get().then(res=>{
      if(!res.data[0].Name){
        console.log("未实名认证！")
        that.setData({
          iswindow: false,
        })
        wx.showModal({
          // cancelColor: 'pink',
          title:"提示！",
          content:"需要实名认证",
          confirmText:"去认证",
          confirmColor:'red',
          success (res) {
            if (res.confirm) {
              //  console.log('用户点击去认证按钮')
               wx.navigateTo({
                 url: '/pages/authentication/authentication',
               })
             } else if (res.cancel) {
              //  console.log('用户点击取消按钮')
             }
           }
        })
      }
      else{
        // that.setData({
        //   iswindow: false
        // })
        console.log("AuthInfo:", app.globalData.AuthInfo)
        const db = wx.cloud.database()
        db.collection("Order").where({
          _openid:app.globalData.openid,
        }).get().then(res=>{
          var flag = true
          //检测该用户是否还有未完成order，flag=false即代表还有未完成oredr
          for(var i=0;i<res.data.length;i++){
            if(res.data[i].isfinished == false){
              flag = false
              break
            }
          }
          if(flag == false){
            wx.showModal({
              title: "提示！",
              content: "您还有未完成的预约！"
            })
          }else{
            wx.showToast({
              title: '预约成功！',
              icon:'success'
            })
            db.collection("Order")
            .get().then(res=>{
              that.setData({
                index: res.data.length +1
              })
              console.log("您的预约号为",that.data.index)
              db.collection("Order").add({
                data:{
                  index: that.data.index,
                  doctorInfo: that.data.doctorInfo,
                  PName: app.globalData.AuthInfo[0].Name,
                  DName: that.data.doctorInfo[0].doctorName,
                  isfinished: false
                }
              }).then(res=>{
                console.log("添加Order成功！")
                wx.switchTab({
                  url: '/pages/index/index',
                })
              })
            })
          }
        })
      }
    })
   
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})