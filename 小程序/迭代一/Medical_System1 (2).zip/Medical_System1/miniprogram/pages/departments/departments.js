// pages/departments/departments.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    iswindow: false,
    hospital_id: 0,
    doctorInfo:'',
    hos0:[{
      Name: "内科",
      doctors:["张三","李四"]
    },{
      Name: "外科",
      doctors:["王大","王二"]
    }],
    list:[{
      Name: "内科",
      doctors:["张三","李四"]
    },{
      Name: "外科",
      doctors:["王大","王二"]
    }],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    this.setData({
      hospital_id: app.globalData.hospital_id
    })
    console.log(app.globalData.hospital_id)
  },

  ShowInfo:function(e){
    let that = this
    console.log(e.target.id)
    const db = wx.cloud.database()
    db.collection("Users").where({
      doctorName: e.target.id
    }).get().then(res=>{
      that.setData({
        doctorInfo:res.data[0].doctorInfo
      })
      console.log(res.data[0].doctorInfo[0].doctorName)
      console.log("医生信息：",that.data.doctorInfo)
    })
    that.setData({
      iswindow: true
    })
  },

  cancel: function(){
    let that = this
    that.setData({
      iswindow: false
    })
  },
  confirm: function(){
    wx.showToast({
      title: '预约成功！',
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})