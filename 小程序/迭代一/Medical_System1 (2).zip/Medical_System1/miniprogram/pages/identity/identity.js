// pages/identity/identity.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: { 
    openid: '',
    islogin:'',
    doctor_register: false,
    admin_register: false,
    hospital_Index: 0,
    hospital: ['请选择医院','第一人民医院','第二人民医院','第三人民医院','第四人民医院'],
    departments:['请选择科室'],
    department_Index:0,
    doctorName: '',
    gender_Index: 0,
    gender: ['请选择性别','男','女'],
    doctorAge:'',
    doctorInfo:[{
      doctorName:'',
      hospital:'',
      gender:'',
      doctorAge:'',
    }]
  },
  globalData: {
    userInfo: null,
    openid: '',
    hospital_id: 0,
    hospital_Info:[]
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
  },

  patients(){
    let that = this
    that.addPatient()
    wx.switchTab({
      url: '/pages/me/me',
    })
  },

  doctors(){
    let that = this
    const db = wx.cloud.database()
    db.collection("Users").where({
      _openid: app.globalData.openid
    })
    .get().then(res=>{
      console.log(!res.data[0].doctor)
      if(!res.data[0].doctor){
        wx.showModal({
          title: '你不是医生',
          content: "是否注册为医生？",
          success (res) {
            if (res.confirm){
              console.log("选择医院和科室，输入姓名")
              that.setData({
                doctor_register: true
              })
              // wx.showToast({
              //   title: '管理员已通过审核, 注册成功！',
              //   icon: "none",
              //   duration:2000
              // })
              // that.addDoctor()
              
            } else{
              console.log("取消注册为医生")
            }
          },
        })
      }
      else{
        that.addDoctor()
      }
    })
  },
  admin(){
    let that = this
    const db = wx.cloud.database()
    db.collection("Users").where({
      _openid: app.globalData.openid
    })
    .get().then(res=>{
      console.log("在这儿哟", res.data[0].admin)
      console.log(!res.data[0].admin)
      if(!res.data[0].admin){
        wx.showModal({
          title: '你不是管理员',
          content: "是否注册为管理员？",
          success (res) {
            if (res.confirm){
              console.log("确认注册为管理员")
              wx.showToast({
                title: '管理员申请已通过审核, 注册成功！',
                icon: "none",
                duration:2000
              })
              that.addAdmin()

              
            } else{
              console.log("取消注册为管理员")
            }
          },
        })
      }
      else{
        that.addAdmin()
        // wx.switchTab({
        //   url: '/pages/me/me',
        // })
      }
    })
  },

  addPatient(){
    let that = this
    const db = wx.cloud.database()
    db.collection("Users").where({
      _openid: app.globalData.openid
    })
    .update({
      data:{
        islogin: true,
        patient: true,
        // docter: false,
        // admin: false
      }
    }).then(res=>{
      console.log("更新成为病人")
    })
  },

  addDoctor(){
    let that = this
    console.log("更新成功了吗")
    const db = wx.cloud.database()
    db.collection("Users").where({
      _openid: app.globalData.openid
    })
    .update({
      data:{
        islogin: true,
        doctor: true,
        // patient: false,
        // admin: false
      }
    }).then(res=>{
      console.log("更新成为医生")
      wx.switchTab({
        url: '/pages/me/me',
      })
    })
  },

  addAdmin(){
    let that = this
    console.log("更新成功了吗")
    const db = wx.cloud.database()
    db.collection("Users").where({
      _openid: app.globalData.openid
    })
    .update({
      data:{
        islogin: true,
        admin: true,
        // patient: false,
        // docter: false,
      }
    }).then(res=>{
      console.log("更新成为管理员")
    })
  },

  //医生选择医院
  hospital_choose: function(e){
    console.log(e.detail.value)
    // let that = this
    this.setData({
      hospital_Index: e.detail.value,
    })
    // console.log("hospital_Index:" ,typeof this.data.hospital_Index)
    const dd = wx.cloud.database()
    dd.collection("Hospital").where({
      hospital_index: this.data.hospital_Index
    }).get().then(res=>{
      this.setData({
        departments:["请选择科室"],
        department_Index:0,
      })
      console.log(res.data[0].departments.length)
      for(var i = 0;i<res.data[0].departments.length;i++){
        this.data.departments.push(res.data[0].departments[i].name)
      }
      this.setData({
        departments:this.data.departments
      })
      console.log("医院：",this.data.hospital)
      console.log("科室：",this.data.departments)

    })
    console.log("选择的医院：", this.data.hospital[this.data.hospital_Index])
  },

  //医生选择科室
  department_choose:function(e){
    this.setData({
      department_Index: e.detail.value
    })
    console.log("Range:",this.data.departments)
    console.log("选择的科室：",e.detail.value)
  },
  //医生姓名
  set_doctorName:function(e){
    this.setData({
      doctorName: e.detail.value,
    })
  },

  //医生选择性别
  gender_choose:function(e){
    this.setData({
      gender_Index: e.detail.value
    })
  },

  //医生年龄
  set_doctorAge:function(e){
    this.setData({
      doctorAge: e.detail.value
    })
  },

  doctor_cancel: function(){
    let that = this
    that.setData({
      doctor_register: false,
      hospital_Index: 0,
      department_Index:0,
      gender_Index: 0,
      doctorName: '',
      doctorAge: ''
    })
  },
  doctor_confirm:function(){
    let that = this
    if(that.data.hospital_Index!=0&&that.data.gender_Index!=0&&that.data.doctorName!=''&&that.data.doctorAge!=''&&that.data.department_Index!=0){
      const doctorName = that.data.doctorName
      const hospital = that.data.hospital[that.data.hospital_Index]
      const gender = that.data.gender[that.data.gender_Index]
      const doctorAge = that.data.doctorAge
      const department = that.data.departments[that.data.department_Index]
      const db= wx.cloud.database()
      const _ = db.command
      db.collection("Users").where({
        _openid: app.globalData.openid
      }).update({
        data:{
          doctorInfo: _.push({doctorName,hospital,department,gender,doctorAge,}),
          doctor: true,
          doctorName: that.data.doctorName,
          hospital:that.data.hospital[that.data.hospital_Index],
          department: that.data.departments[that.data.department_Index],
          Age: that.data.doctorAge,
          gender: that.data.gender[that.data.gender_Index]
        }
      })
      // var depart_doctors=[{name:'',doctors:[]}]
      // db.collection("Hospital").where({
      //   hospitalName: hospital
      // }).get().then(res=>{
      //   console.log("医院信息：", res.data)
      //   for(var i=0;i<res.data[0].departments.length;i++){
      //     depart_doctors[that.data.department_Index].doctors.push(doctorName)
      //   }
      //   console.log("depart_doctors:",depart_doctors)
      // })
      // .update({
      //   data:{
      //     departments:depart_doctors
      //   }
      // })
      wx.showToast({
        title: '注册成功！',
        icon:'success',
        duration: 3000,
        success:function(){
          wx.switchTab({
            url: '/pages/me/me',
          })
        }
      })
    }else{
      wx.showToast({
        title: '请完成信息填入！',
        icon:'error',

      })
    }
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})