// pages/authentication/authentication.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    gender_Index: 0,
    gender: ['请选择性别','男','女'],
    Name:'',
    Age: 0,
    phone:'',
    isShow: false,
    openid:'',
    isInfo: false,
  },
  // globalData:{
  //   AuthInfo:[{
  //     Name: '',
  //     Age:0,
  //     phone:'',
  //     gender:'',
  //   }]
  // },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    console.log("1!1",app.globalData.AuthInfo)
    const db =wx.cloud.database()
    db.collection("Users").where({
      _openid: app.globalData.openid
    }).get().then(res=>{
      console.log("调用成功")
      console.log(res)
      if(!res.data[0].Name){
        console.log("未实名")
        this.setData({
          isShow: true,
        })
      }else{
        console.log("已实名")
        this.setData({
          isInfo: true,
          Name: res.data[0].Name,
          gender: res.data[0].gender,
          Age: res.data[0].Age,
          phone: res.data[0].phone
        })
        app.globalData.AuthInfo[0].Name = this.data.Name
        app.globalData.AuthInfo[0].gender = this.data.gender[this.data.gender_Index],
        app.globalData.AuthInfo[0].Age = this.data.Age
        app.globalData.AuthInfo[0].phone = this.data.phone
        console.log("@@@@@@@@@@",app.globalData.AuthInfo)
      }
      
    })
  },


   //用户姓名
   set_Name:function(e){
    this.setData({
      Name: e.detail.value,
    })
  },

  //用户选择性别
  gender_choose:function(e){
    this.setData({
      gender_Index: e.detail.value
    })
  },

  //用户年龄
  set_Age:function(e){
    this.setData({
      Age: e.detail.value
    })
  },

  //手机号
  set_phone:function(e){
    this.setData({
      phone: e.detail.value
    })
  },

  confirm(){
    let that = this
    if(that.data.Name&&that.data.gender&&that.data.Age&&that.data.phone){
      console.log("已填写完毕")
      const db = wx.cloud.database()
      db.collection("Users").where({
        _openid:app.globalData.openid
      }).update({
        data:{
          Name: that.data.Name,
          gender: that.data.gender[that.data.gender_Index],
          Age: that.data.Age,
          phone: that.data.phone,
        }
      }).then(res=>{
        app.globalData.AuthInfo[0].Name = that.data.Name
        app.globalData.AuthInfo[0].gender = that.data.gender[that.data.gender_Index],
        app.globalData.AuthInfo[0].Age = that.data.Age
        app.globalData.AuthInfo[0].phone = that.data.phone
        that.setData({
          isInfo: true,
          isShow: false,
        })
        that.onLoad()
      })
    }
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})