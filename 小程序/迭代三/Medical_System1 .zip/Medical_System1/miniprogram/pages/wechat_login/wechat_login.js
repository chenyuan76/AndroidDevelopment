const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    userInfo: null,
    everlogin: false,  //检测用户openid是否已存入数据库中，即用户是否已经登录过该小程序
    everwechat: false,
    everphone: false,
    nickName: '',
    openid: '',
    islogin: false,
    iswindow:false,
    phone_number:'',
    password:'',
    phone_login:false,
    wechat_login:false
  },



    /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let openid = wx.getStorageSync('openid')
    if(!openid){
      console.log("没有openid")
      //向app实例一个注册回调函数
      getApp().openidCallBack= (openid)=>{
        console.log('-----------------')
        console.log(openid)
        if(openid){
          wx.setStorageSync('openid', openid)
          console.log("已回调，设置了openid")
          this.checkLogin()
        }
      }
    }else{
      console.log('have openid')
      this.checkLogin()
    }

},

//微信登录，授权
wechat_login:function(){
  let that = this
  console.log("444 everlogin: ", that.data.everlogin)
  console.log(!that.data.wechat_login)
  console.log(that.data.wechat_login)
  if (that.data.everlogin == false){
    wx.getUserProfile({
      desc: '获取用户信息',
      success (res) {
        console.log("用户信息", res.userInfo.nickName)
        wx.navigateTo({
          url: '/pages/identity/identity',
        })
        //设置全局用户信息
        app.globalData.userInfo = res.userInfo
        //设置局部用户信息
        that.setData({
          userInfo: res.userInfo
        })
        const db = wx.cloud.database()
        db.collection("Users")
        .add({
          data: {
            avatarUrl:app.globalData.userInfo.avatarUrl,
            nickName: app.globalData.userInfo.nickName,
            everlogin: true,
            wechat_login: true,
          }
        })   
        that.setData({
          everlogin: true,
          wechat_login: true
        })
      },
      fail(res) {
        wx.showToast({
          title: '登陆失败',
          icon: 'error'
        })
      }
    })
  } else if(!that.data.wechat_login){
    console.log("怎么是你？")
    wx.getUserProfile({
      desc: '获取用户信息',
      success (res) {
        console.log("用户信息", res.userInfo.nickName)
        wx.navigateTo({
          url: '/pages/identity/identity',
        })
        //设置全局用户信息
        app.globalData.userInfo = res.userInfo
        //设置局部用户信息
        that.setData({
          userInfo: res.userInfo
        })
        const db = wx.cloud.database()
        db.collection("Users").where({
          _openid: app.globalData.openid
        })
        .update({
          data:{
            avatarUrl:app.globalData.userInfo.avatarUrl,
            nickName: app.globalData.userInfo.nickName,
            wechat_login: true,
            everlogin: true,
          }
        })
        that.setData({
          wechat_login: true,
        })
      },
      fail(res) {
        wx.showToast({
          title: '登陆失败',
          icon: 'error'
        })
      }
    })
  }else {
    console.log("没有登录直接进入小程序")
    wx.navigateTo({
      url: '/pages/identity/identity',
    })
  }
},

//手机号注册登录，输手机号密码
phone_login:function(){
  let that = this
  that.setData({
    iswindow: true,
  })
},

set_PhoneNumber:function(e){
  this.setData({
    phone_number: e.detail.value
  })
},
set_Password:function(e){
  this.setData({
    password: e.detail.value
  })
},

cancel: function(){
  let that = this
  that.setData({
    iswindow: false
  })
},
confirm:function(){
  let that = this
  if(Math.floor(that.data.phone_number/10000000000)==1){
    if(that.data.password){
      if(that.data.everlogin==false){
        const db = wx.cloud.database()
        db.collection("Users")
        .add({
          data:{
            phone_number: that.data.phone_number,
            password: that.data.password,
            phone_login: true,
            everlogin: true,
          }
        })
        that.setData({
          everlogin: true,
          phone_login: true
        })
        wx.navigateTo({
          url: '/pages/identity/identity',
        })
      }else if(!that.data.phone_login){
        const db = wx.cloud.database()
        db.collection("Users").where({
          _openid: app.globalData.openid
        })
        .update({
          data:{
            phone_number: that.data.phone_number,
            password: that.data.password,
            phone_login: true,
            everlogin: true,
          }
        })
        that.setData({
          phone_login: true
        })
      }else{
        const db = wx.cloud.database()
        db.collection("Users").where({
          _openid: app.globalData.openid
        }).get().then(res=>{
          if(that.data.phone_number!=res.data[0].phone_number){
            wx.showToast({
              title: '账号错误！',
              icon: 'error'
            })
          }else if(that.data.password!=res.data[0].password){
            wx.showToast({
              title: '密码错误！',
              icon: 'error',
            })
          }else{
            wx.navigateTo({
              url: '/pages/identity/identity',
            })
          }
        })
      }
    }else{
      wx.showModal({
        title: '提示！',
        content:'请输入密码！',
      })
    }
  }else{
    wx.showModal({
      title: '提示！',
      content:'请输入正确的手机号！',
    })
  }
},


  //检测用户openid是否已存入数据库中，即用户是否已经登录过该小程序,判断是否需要授权
  checkLogin:function () {
    let that = this
    console.log("checkLogin成功")
    const db = wx.cloud.database()
    db.collection("Users").where({
      _openid: wx.getStorageSync('openid')
    }).get().then(res => {
      if(res.data.length == 0){
        console.log("用户第一次登录")
      }
      else if(res.data[0].islogin==true){
        console.log("用户已经登录过")
        that.setData({
          everlogin: res.data[0].everlogin,
          islogin: res.data[0].islogin,
          phone_login: res.data[0].phone_login,
          wechat_login: res.data[0].wechat_login,
        })
        wx.switchTab({
          url: '/pages/me/me',
        })
        
      }else{
        console.log("用户重新登录")
        that.setData({
          everlogin: res.data[0].everlogin,
          islogin: res.data[0].islogin,
          phone_login: res.data[0].phone_login,
          wechat_login: res.data[0].wechat_login,
        })
      }
    })
  },

 

  //向数据库中添加用户信息
  addUser(){
    const db = wx.cloud.database()
    db.collection("Users")
    .add({
      data: {
        nickName: app.globalData.userInfo.nickName,
        everlogin: true,
        islogin: false,
      }
    }).then(res2 => {
      console.log('用户openid和nickName添加成功')
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})