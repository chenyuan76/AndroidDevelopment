
const app = getApp()
Page({
  /**
   * 页面的初始数据
   */
  data: {
    swiperImgs: [
      "https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fimg95.699pic.com%2Fxsj%2F12%2F8n%2Fss.jpg%21%2Ffw%2F700%2Fwatermark%2Furl%2FL3hzai93YXRlcl9kZXRhaWwyLnBuZw%2Falign%2Fsoutheast&refer=http%3A%2F%2Fimg95.699pic.com&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=auto?sec=1655817909&t=98999d24f65fb4a89c131c77e72dc13f",
      "https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fimg.236z.com%2Fuploads%2F2021%2F1018%2F20211018_1634545264387780.png&refer=http%3A%2F%2Fimg.236z.com&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=auto?sec=1655818021&t=211fdb07a2dc5a24a4d4088809aa540c",
      "https://gimg2.baidu.com/image_search/src=http%3A%2F%2Finews.gtimg.com%2Fnewsapp_bt%2F0%2F13912260932%2F1000.jpg&refer=http%3A%2F%2Finews.gtimg.com&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=auto?sec=1655817610&t=47d9f9a8b48ce309fe752201bdf13d49"
    ],
    bg: "#C79C77",
    Height: "", //这是swiper要动态设置的高度属性,
    index: 1,
    PName:'',
    DoctorInfo:[],
    isfinished: true,
    identity: '',
    DoctorOrder:[],
    adminhospital_id:0,
    hos_departments: [],
    add_depart: false,
    add_depart_name:'',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // console.log("index页面")
    // console.log(app.globalData.openid)
    // this.showOrder()
  },

  order(){
    wx.navigateTo({
      url: '/pages/order/order',
    })
  },
  consult(){
    wx.navigateTo({
      url: '/pages/consult/consult',
    })
  },
  imgHeight:function(e){
    var winWid = wx.getSystemInfoSync().windowWidth; //获取当前屏幕的宽度
    var imgh=e.detail.height;//图片高度
    var imgw=e.detail.width;//图片宽度
    var swiperH=winWid*imgh/imgw + "px"//等比设置swiper的高度。 即 屏幕宽度 / swiper高度 = 图片宽度 / 图片高度  ==》swiper高度 = 屏幕宽度 * 图片高度 / 图片宽度
    this.setData({
      Height:swiperH//设置高度
    })
  },

  showPatientOrder(){
    let that = this
    const db = wx.cloud.database()
    db.collection("Order").where({
      _openid: wx.getStorageSync('openid'),
      // isfinished: false,
    }).get().then(res=>{
      var flag = true
      console.log("出啥问题了？？", res.data.length)
      for(var i=0;i<res.data.length;i++){
        // console.log("检查是否有完成预约")
        if(res.data[i].isfinished == false){
          // console.log("还有未完成预约！")
          that.setData({
            index: res.data[i].index,
            PName: res.data[i].PName,
            DoctorInfo: res.data[i].doctorInfo,
            isfinished: false
          })
          break
        }
      }
    })
  },
  showDoctorOrder(){
    let that = this
    that.setData({
      DoctorOrder:[]
    })
    const db = wx.cloud.database()
    db.collection("Users").where({
      _openid: wx.getStorageSync('openid')
    }).get().then(res=>{
      var myname = res.data[0].Name
      console.log("myname:", myname )
      db.collection("Order").where({
        DName: myname,
        isfinished:false
      }).get().then(res=>{
        console.log("在这儿！！！！！！！！！！！！！！！！！！", res.data.length)
        for(var i=0;i<res.data.length;i++){
          var list = {index:0,PName:'',DoctorInfo:'',isfinished:false}
          list.index = res.data[i].index
          list.PName = res.data[i].PName
          list.DoctorInfo = res.data[i].doctorInfo
          list.isfinished = false
          that.data.DoctorOrder.push(list)
          that.setData({
            DoctorOrder: that.data.DoctorOrder,
            isfinished: false
          })
        }
        console.log("DoctorOrder:", that.data.DoctorOrder)
      })
    })
  },

  set_finished:function(e){
    let that = this

    var id = parseInt(e.target.id)
    console.log("index:" ,id)
    const db = wx.cloud.database()
    db.collection("Order").where({
      index: id,
    }).update({
      data:{
        isfinished: true
      }
    }).then(res=>{
      this.showDoctorOrder()
    })
  },

  showAdminOrder(){
    let that = this
    const db = wx.cloud.database()
    db.collection("Users").where({
      _openid: wx.getStorageSync('openid')
    }).get().then(res=>{
      that.setData({
        adminhospital_id: res.data[0].adminhospital_id
      })
      db.collection("Hospital").where({
        hospital_index: that.data.adminhospital_id
      }).get().then(res=>{
        that.setData({
          hos_departments:res.data[0].departments
        })
        console.log(that.data.hos_departments)
      })
    })
  },

  //管理员删除科室
  delete:function(e){
    let that = this
    const name = e.target.id
    var flag = false//该科室下的医生是否还有未完成预约
    console.log("name:",name)
    const db = wx.cloud.database()
    const hospital = ['第一人民医院','第二人民医院','第三人民医院','第四人民医院']
    // db.collection("Users").where({
    //   hospital: hospital[that.data.adminhospital_id-1],
    //   department: name,
    // }).get().then(res=>{
    //   const doctors=[]
    //   for(var i = 0;i<res.data.length;i++){
    //     doctors.push(res.data[i].Name)
    //   }
    //   console.log("该医院该科室的医生：",doctors)
    //   for(var i = 0;i<doctors.length;i++){
    //     db.collection("Order").where({
    //       DName: doctors[i]
    //     }).get().then(res=>{
    //       console.log(res,"++++++++++++")
    //       for(var j = 0;j<res.data.length;j++){
    //         if(res.data[j].isfinished == false){
    //           flag = true;
    //           break
    //         }
    //       }
          
    //     })
    //   }
    //   console.log("flag::",flag)
      
    // })
    // console.log(flag,"flag")
    wx.showModal({
      confirmColor: 'red',
      content: '确认删除此科室吗？',
      success:function(res){
        if(res.confirm){
          const db = wx.cloud.database()
          const _ = db.command
          console.log("!!!!!!!!!!!!!!!!!!!!!!!!!!!")
          db.collection("Hospital").where({
            hospital_index: that.data.adminhospital_id
          }).update({
            data:{
              departments: _.pull({
                name: name
              })
            }
          }).then(res=>{
            that.onShow()
          })
        }
      }
    })
  },

  //管理员添加科室
  add:function(e){
    let that = this
    that.setData({
      add_depart: true
    })
   
  },

  //输入科室名称
  add_depart:function(e){
    this.setData({
      add_depart_name: e.detail
    })
  },

  //输入完科室名确认添加
  confirm(){
    let that = this
    if(that.data.add_depart_name.value){
      const name = that.data.add_depart_name.value
      const doctors = []
      const db = wx.cloud.database()
      const _ = db.command
      db.collection("Hospital").where({
        hospital_index : that.data.adminhospital_id
      }).update({
        data:{
          departments:_.push({doctors,name})
        }
      }).then(res=>{
        that.setData({
          add_depart: false
        })
        that.onShow()
      })
    }
  },

  //取消添加
  cancel(){
    that.setData({
      add_depart:false
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    const db = wx.cloud.database()
    db.collection("Users").where({
      _openid:wx.getStorageSync('openid')
    }).get().then(res=>{
        this.setData({
          identity: res.data[0].identity,
        })
        console.log("identity:",this.data.identity)
        if(this.data.identity=='病人'){
          this.showPatientOrder()
        }else if(this.data.identity=='医生'){
          this.showDoctorOrder()
        }
        else if(this.data.identity=='管理员'){
          this.showAdminOrder()
        }
    })


},


  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})