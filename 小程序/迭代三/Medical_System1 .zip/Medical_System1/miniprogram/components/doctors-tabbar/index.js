// // components/medical-tabbar/index.js
// Component({
//   /**
//    * 组件的属性列表
//    */
//   properties: {
//     selected: {
//       type: Number,
//       default:1
//     }
//   },  

//   /**
//    * 组件的初始数据
//    */
//   data: {
//     // selected:0,
//     color: "#7A7E83",
//     selectedColor: "#3cc51f",
//     list: [
//       {
//         "pagePath": "../../pages/index_doctors/index_doctors",
//         "text": "医生首页",
//         "iconPath": "../../pics/icon_order_no.png",
//         "selectedIconPath": "../../pics/icon_order_yes.png"
//       },
//       {
//         "pagePath": "../../pages/me_doctors/me_doctors",
//         "text": "个人中心",
//         "iconPath": "../../pics/icon_me_no.png",
//         "selectedIconPath": "../../pics/icon_me_yes.png"
//       }
//     ]
//   },


//   /**
//    * 组件的方法列表
//    */
//   methods: {
//     switchTab(e) {
//       let data = e.currentTarget.dataset
//       let url = data.path
//       wx.redirectTo({
//         url
//       })
//     }
//   }
// })
