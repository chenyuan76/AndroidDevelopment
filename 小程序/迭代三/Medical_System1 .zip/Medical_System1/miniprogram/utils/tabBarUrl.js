// // 病人
// export const patients = [
//   {
//     "pagePath": "pages/index/index",
//     "text": "预约挂号",
//     "iconPath": "/pics/icon_order_no.png",
//     "selectedIconPath": "pics/icon_order_yes.png"
//   },
//   {
//     "pagePath": "pages/consult/consult",
//     "text": "在线咨询",
//     "iconPath": "/pics/icon_order_no.png",
//     "selectedIconPath": "pics/icon_order_yes.png"
//   },
//   {
//     "pagePath": "pages/me/me",
//     "text": "我的",
//     "iconPath": "/pics/icon_me_no.png",
//     "selectedIconPath": "pics/icon_me_yes.png"
//   },
// ]

// //医生
// export const doctors = [
//   {
//     "pagePath": "pages/consult/consult",
//     "text": "在线咨询",
//     "iconPath": "/pics/icon_order_no.png",
//     "selectedIconPath": "pics/icon_order_yes.png"
//   },
//   {
//     "pagePath": "pages/me_doctors/me_doctors",
//     "text": "个人中心",
//     "iconPath": "/pics/icon_me_no.png",
//     "selectedIconPath": "pics/icon_me_yes.png"
//   }
  
// ]