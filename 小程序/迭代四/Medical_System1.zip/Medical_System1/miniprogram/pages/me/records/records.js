// pages/me/records/records.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    list:[],
    identity: '',
    name: '',
    isfinished:false,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    let that = this
    const db = wx.cloud.database()
    db.collection("Users").where({
      _openid: wx.getStorageSync('openid')
    }).get().then(res=>{
      //判断用户是否实名，若未实名无法查看记录，前去实名
      if(!res.data[0].Name){
        console.log("未实名认证！")
        that.setData({
          iswindow: false,
        })
        wx.showModal({
          // cancelColor: 'pink',
          title:"提示！",
          content:"需要实名认证",
          confirmText:"去认证",
          confirmColor:'red',
          success (res) {
            if (res.confirm) {
              //  console.log('用户点击去认证按钮')
               wx.navigateTo({
                 url: '/pages/authentication/authentication',
               })
             } else if (res.cancel) {
             }
           }
        })
      }else{
        that.setData({
          name: res.data[0].Name
        })

      }

      //判断用户身份
      that.setData({
        identity: res.data[0].identity
      })
      if(that.data.identity == '病人'){
        that.patient_records()
      }else if(that.data.identity == '医生'){
        that.doctor_records()
      }
    })
  },

  //身份为病人时的预约记录
  patient_records(){
    let that = this
    const db = wx.cloud.database()
    db.collection("Order").where({
      PName: that.data.name
    }).get().then(res=>{
      for(var i = 0; i<res.data.length;i++){
        if(res.data[i].isfinished==true){
          that.data.list.push(res.data[i])
        }else{
          that.data.list.unshift(res.data[i])
        }
      }
      that.setData({
        list: that.data.list
      })
      console.log("list",that.data.list)
    })
  },

  //身份为医生时的看诊记录
  doctor_records(){
    let that = this
    const db = wx.cloud.database()
    db.collection("Order").where({
      DName: that.data.name
    }).get().then(res=>{
      for(var i = 0; i<res.data.length;i++){
        if(res.data[i].isfinished==true){
          that.data.list.push(res.data[i])
        }else{
          that.data.list.unshift(res.data[i])
        }
      }
      that.setData({
        list: that.data.list
      })
      console.log("list",that.data.list)

    })
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})