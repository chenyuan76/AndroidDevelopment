const envList = [{"envId":"cloud1-4gm2rll19e59bb4d","alias":"cloud1"}]
const isMac = false
module.exports = {
    envList,
    isMac
}